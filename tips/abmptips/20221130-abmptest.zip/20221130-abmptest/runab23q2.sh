#!/bin/bash
nproc=20  # Number of processor
workdir=`pwd`

abinit_dir=/home/share/bin/open-ver1rev23a-20220208-mizuho
py_script=mkinp_openver1rev20.py
bin_name=abinitmp
mpicmd=mpirun

fname=${1%.*}
ajfname=$fname.ajf
inpname=$fname.ajf2
outname=$fname.log

cd $workdir

python $abinit_dir/$py_script < $ajfname > $inpname
bsub -n $nproc -m 'fmoamed01 fmoamed02 fmoamed04' -i $inpname -o $outname $mpicmd -n $nproc $abinit_dir/$bin_name

# mpi command
#vnl or chem2: intelmpi-mpiexec
#others: mpirun

