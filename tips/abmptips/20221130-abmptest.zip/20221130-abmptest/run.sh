python -m abmptools.generateajf -i gly5.pdb --method MP2D --resp --nonbo
python -m abmptools.generateajf -i gly5.pdb --method MP2D --resp 
python -m abmptools.generateajf -i gly5.pdb --method MP2D  --nonbo
python -m abmptools.generateajf -i gly5.pdb --method MP2D  
python -m abmptools.generateajf -i gly5.pdb --method HF --resp --nonbo
python -m abmptools.generateajf -i gly5.pdb --method HF --resp 
python -m abmptools.generateajf -i gly5.pdb --method HF  --nonbo
python -m abmptools.generateajf -i gly5.pdb --method HF  
python -m abmptools.generateajf -i gly5.pdb --method HF
python -m abmptools.generateajf -i gly5.pdb --method MP2
python -m abmptools.generateajf -i gly5.pdb --method MP3
python -m abmptools.generateajf -i gly5.pdb --method HF+D
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb -bsse --method HF
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb -bsse --method MP2
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb -bsse --method MP3
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb -bsse --method HF+D
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb  --method HF
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb  --method MP2
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb  --method MP3
python -m abmptools.generateajf -i gly5.pdb --nopieda -pb  --method HF+D
python -m abmptools.generateajf -i gly5.pdb --nopieda  -bsse --method HF
python -m abmptools.generateajf -i gly5.pdb --nopieda  -bsse --method MP2
python -m abmptools.generateajf -i gly5.pdb --nopieda  -bsse --method MP3
python -m abmptools.generateajf -i gly5.pdb --nopieda  -bsse --method HF+D
python -m abmptools.generateajf -i gly5.pdb --nopieda   --method HF
python -m abmptools.generateajf -i gly5.pdb --nopieda   --method MP2
python -m abmptools.generateajf -i gly5.pdb --nopieda   --method MP3
python -m abmptools.generateajf -i gly5.pdb --nopieda   --method HF+D
python -m abmptools.generateajf -i gly5.pdb  -pb -bsse --method HF
python -m abmptools.generateajf -i gly5.pdb  -pb -bsse --method MP2
python -m abmptools.generateajf -i gly5.pdb  -pb -bsse --method MP3
python -m abmptools.generateajf -i gly5.pdb  -pb -bsse --method HF+D
python -m abmptools.generateajf -i gly5.pdb  -pb  --method HF
python -m abmptools.generateajf -i gly5.pdb  -pb  --method MP2
python -m abmptools.generateajf -i gly5.pdb  -pb  --method MP3
python -m abmptools.generateajf -i gly5.pdb  -pb  --method HF+D
python -m abmptools.generateajf -i gly5.pdb   -bsse --method HF
python -m abmptools.generateajf -i gly5.pdb   -bsse --method MP2
python -m abmptools.generateajf -i gly5.pdb   -bsse --method MP3
python -m abmptools.generateajf -i gly5.pdb   -bsse --method HF+D
python -m abmptools.generateajf -i gly5.pdb    --method HF
python -m abmptools.generateajf -i gly5.pdb    --method MP2
python -m abmptools.generateajf -i gly5.pdb    --method MP3
python -m abmptools.generateajf -i gly5.pdb    --method HF+D
